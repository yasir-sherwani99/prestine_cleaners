<div class="container additional_information">
	<div class="row">
    	<div class="col-lg-12">
    		<h4 class="mb-5">Cleaning Schedule</h4>

    		@include('front.booking.inc.sections.cleaning_date')

			@include('front.booking.inc.sections.additional_info')

			<p>
				(<span class="mandatory">*</span>) Mandatory
			</p>

		</div>
	</div>
</div>
