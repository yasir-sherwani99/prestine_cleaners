<div class="container">
    <div class="row">
        <div class="col-lg-12">
        	<h4 class="mb-5">Choose Service</h4>
        	
        	@include('front.booking.inc.sections.service')
        	
			@include('front.booking.inc.sections.cleaning_area')

			<p>
				(<span class="mandatory">*</span>) Mandatory
			</p>
		</div>
	</div>
</div>