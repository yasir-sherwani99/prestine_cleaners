<div class="container">
    <div class="row">
        <div class="col-lg-8">
        	<h4 class="mb-5">2.&nbsp;Service Details</h4>

        	@include('front.booking.inc.tenancy_details')

			@include('front.booking.inc.carpet_rug_details')

			@include('front.booking.inc.upholstery_details')

			@include('front.booking.inc.window_details')

			@include('front.booking.inc.oven_details')

			@include('front.booking.inc.one_off_details')

			@include('front.booking.inc.fortnightly_details')

			@include('front.booking.inc.office_details')

			@include('front.booking.inc.after_builders_details')

			@include('front.booking.inc.mattress_details')

			@include('front.booking.inc.sofa_details')

			<p>
				(<span class="mandatory">*</span>) Mandatory
			</p>

		</div>
	</div>
</div>