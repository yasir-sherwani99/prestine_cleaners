<div class="service_details unknown_service_details">
	
	<h4 class="text-danger text-center"><i class="fa fa-warning"></i>&nbsp;&nbsp;Unknown service selected!</h4>
	
</div>