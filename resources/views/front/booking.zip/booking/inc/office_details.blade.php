<div class="container service_details office_details">
	<div class="row">
    	<div class="col-lg-12">
    		<h4 class="mb-5">Office Service Details</h4>
	
			@include('front.booking.inc.sections.office_rooms')

			@include('front.booking.inc.sections.cleaning_schedule')

			<p>
				(<span class="mandatory">*</span>) Mandatory
			</p>
		</div>
	</div>
</div>