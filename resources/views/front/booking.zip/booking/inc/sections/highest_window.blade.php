<div class="choose_floor_highest_window radio_error d-none mb-4">
    <div class="row">
        <div class="col-md-12 col-12">
            <label>
                <strong>On which floor is the highest window? <span class="mandatory">*</span>
                </strong>
            </label>
        </div>
    </div>
	<div class="row">
		<div class="col-md-3 col-12">
            <div class="radio icheck-emerland"> 
                <input type="radio" name="highest_window_location" id="window_ground" value="ground">
                <label for="window_ground">Ground</label>
            </div>
        </div>
        <div class="col-md-3 col-12">
    	    <div class="radio icheck-emerland"> 
                <input type="radio" name="highest_window_location" id="window_first_floor" value="first-floor">
                <label for="window_first_floor">First Floor</label>
  		    </div>
        </div>
        <div class="col-md-3 col-12">
  		    <div class="radio icheck-emerland"> 
                <input type="radio" name="highest_window_location" id="window_second_floor" value="second-floor">
                <label for="window_second_floor">Second Floor</label>
  		    </div>
        </div>
        <div class="col-md-3 col-12">
  		    <div class="radio icheck-emerland"> 
                <input type="radio" name="highest_window_location" id="window_third_floor" value=" third-floor">
                <label for="window_third_floor">Third Floor</label>
  		    </div>
        </div>
    </div>
</div>
