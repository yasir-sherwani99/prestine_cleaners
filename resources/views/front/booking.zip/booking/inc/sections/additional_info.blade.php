<div class="choose_additional_info mb-4">
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
            	<label for="additional_info"><strong>If you have additional information, please add them below</strong></label>
                <textarea name="additional_info" id="additional_info" rows="5" class="form-control" placeholder="Additional information"></textarea>
                <small>Maximum 500 characters including spaces.</small> 	            
            </div>
        </div>
    </div>
</div>