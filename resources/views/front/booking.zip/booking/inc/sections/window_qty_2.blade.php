<div class="choose_window_qty_2 mb-4 d-none">
    <div class="row">
		<div class="col-md-6">
            <div class="form-group"> 
        		<label for="windows_qty"><strong>How many windows do you have? <span class="mandatory">*</span></strong></label>
                <input type="number" id="windows_qty" name="window_qty" min="1" class="form-control">
                <small class="d-block">*only digits allowed</small>
            </div>
    	</div>
    </div>
</div>