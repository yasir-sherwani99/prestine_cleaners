<div class="choose_customer radio_error mb-4">
	<div class="row">
  		<div class="col-md-12">
	        <div class="form-check-inline"> 
	      		<label class="form-check-label">
	      			<input type="radio" class="form-check-input customer" name="customer" value="1" onclick="toggleLogin(1)" checked="checked">
	      			<strong>Existing Customer</strong>
	      		</label>
	      	</div>
	      	<div class="form-check-inline"> 
	      		<label class="form-check-label">
	      			<input type="radio" class="form-check-input customer" name="customer" value="2" onclick="toggleLogin(2)">
	      			<strong>New Customer</strong>
	      		</label>
    		</div>
    	</div>
    </div>
</div>