<div class="choose_login mb-4 p-4" style="background-color: #fffacd !important;">
	<p class="text-muted">If you are an existing customer, please enter your username and password.</p>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
            	<label class="d-block" for="login_email"><strong>Email <span class="mandatory">*</span></strong></label>
                <input type="email" id="login_email" name="login_email" class="form-control" placeholder="Email" autocomplete="off"> 
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
            	<label class="d-block" for="login_password"><strong>Password <span class="mandatory">*</span></strong></label>
                <input type="password" id="login_password" name="login_password" class="form-control" placeholder="Password"> 	            
            </div>
        </div>
    </div>
</div>